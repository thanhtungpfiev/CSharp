﻿using System;

namespace CSharpPractice
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            string message = Console.ReadLine();
            Console.WriteLine($"Echo: {message}");
            Console.ReadLine();
        }
    }
}
